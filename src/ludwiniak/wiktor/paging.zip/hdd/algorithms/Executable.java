package ludwiniak.wiktor.hdd.algorithms;

public interface Executable {
    int execute();
}
