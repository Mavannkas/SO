package ludwiniak.wiktor.L5.V2;


import java.util.List;

public interface Chooser {
    CPU choose(List<CPU> cpuList);
}
