package ludwiniak.wiktor.L5.V2;

public class TickCounter {
    public static int time = 0;
}
